package br.com.fiap.organized_scann_api.model;

public enum PortalType {
    QUICK_MAINTENANCE,
    SLOW_MAINTENANCE,
    POLICE_REPORT,
    RECOVERED_MOTORCYCLE
}