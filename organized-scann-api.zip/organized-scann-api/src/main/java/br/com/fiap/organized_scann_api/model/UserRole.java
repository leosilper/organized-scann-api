package br.com.fiap.organized_scann_api.model;

public enum UserRole {
    ADMIN,
    SUPERVISOR,
    OPERATOR
}
